const int MAX = 4;

int main ()
{
    char *names[] = {
                    "Zara Ali",
                    "Hina Ali",
                    "Nuha Ali",
                    "Sara Ali"
    };
    
    int i = 0;
    names[5];
    for ( i = 0; i < MAX; i++)
    {
       printf("Value of names[%d] = %s\n", i, names[i] );
       break;
    }
    
 return 0;
 
}
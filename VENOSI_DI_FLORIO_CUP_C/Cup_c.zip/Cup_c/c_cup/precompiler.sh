javac com/mxgraph/*/*.java
javac java_cup/runtime/*.java
echo "success"
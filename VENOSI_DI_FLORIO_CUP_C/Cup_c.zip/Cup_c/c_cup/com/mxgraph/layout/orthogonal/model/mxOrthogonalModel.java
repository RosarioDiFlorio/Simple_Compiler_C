/**
 * Copyright (c) 2008-2009, JGraph Ltd
 */
package com.mxgraph.layout.orthogonal.model;

import com.mxgraph.view.mxGraph;

/**
 * A custom graph model 
 */
public class mxOrthogonalModel
{
   public mxOrthogonalModel(mxGraph graph)
   {
      // 
   }
}

volatile int v = 4;

int b = 10 - 2 * 4;

int foo(int a, char b){
   
   int a;
    a = 10;
    
    
    
    for(;;)for(;;);
    
    foo2(a,b);  
    
    int b = 0;
    
  
    if(a == b && c <= l || l >= 2)
        a = a + 3; 
    else if(a == 0)
        int a;
    else if(b == 0) 
        int b;
    else
        int a;
    
   while(1){
    printf("ciao mondo");   
   }
    
   
   
   
    
}
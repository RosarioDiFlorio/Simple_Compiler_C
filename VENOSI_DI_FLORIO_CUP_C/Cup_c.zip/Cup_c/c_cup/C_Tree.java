
public class C_Tree  {
    
	public static Tree<String> tree = new Tree<String>("c_program");
        
}

class CNode<String> extends Node{
    int line;
    public CNode(String data,int line){
        super(data);
        this.line = line;
    }
    
    public void setCurrentLine(int line){
        this.line = line;
    }
    
}

class Identifier<String> extends CNode{
	
	public Identifier(String rootData,int line) {
		super(rootData,line);
	}
	
	
}

class ArrayIdentifier<String> extends CNode{
	
	public ArrayIdentifier(String rootData,Node<String> indexArray,int line) {
		super(rootData,line);
		this.addChild(indexArray);
	}
	
	
}


class Constant<String> extends CNode{
	
	public Constant(String rootData,int line) {
		super(rootData,line);
	}
	
	public Constant(String rootData,int line, Node<String>typeConstant) {
		super(rootData,line);
		this.addChild(typeConstant);
	}
	
	
	
}



class ArrayDeclaration<String> extends CNode{

	public ArrayDeclaration(String type,Node<String>name, Node<String> len, Node<String> listNumber,int line) {
		super("ARRAY",line);
		this.addChild(new Node(type));
		this.addChild(name);
		this.addChild(len);
		this.addChild(listNumber);
		
	}
	
	
	
	
}

class Declaration<String> extends CNode{
	
	public Declaration(String type,Node<String>name,  String op, Node<String> expression,int line) {
		super("DEC",line);
		this.addChild(new Node(type));
		this.addChild(name);
		if(expression != null)
                    this.addChild(expression);
		
	}
	
	
	
}

class Assign<String> extends CNode{
	
	public Assign(String rootData,  Node<String> a, Node<String> b,int line) {
		//super(rootData,line);
		super("ASSIGN",line);
		this.addChild(a);
		this.addChild(b);
	}
	
	
	
}

class Conjunction<String> extends CNode{
	
	public Conjunction(String rootData,  Node<String> a, Node<String> b,int line) {
		super(rootData,line);
		
		this.addChild(a);
		this.addChild(b);
		
	}
	
	
	
}
/*
class Plus<String> extends CNode{
	
	public Plus(String rootData,  Node<String> a, Node<String> b,int line) {
		super(rootData,line);
		
		this.addChild(a);
		this.addChild(b);
	}
	
}
*/

class Op<String> extends CNode{
	
	public Op(String rootData,  Node<String> a, Node<String> b,int line) {
		super(rootData,line);
		
		this.addChild(a);
		this.addChild(b);
	}
	
}




class UnaryOperator<String> extends CNode{
	
	public UnaryOperator(Node<String>op, String id, String position,int line) {
		super("UN_OP",line);
		this.addChild(op);
		this.addChild(new Node(id));
		this.addChild(new Node(position));
	}
	
}


class UnaryMinus<String> extends CNode{
	String a;
	public UnaryMinus(String c,Node<String>a,int line) {
		super("UNARYMINUS",line);
		if(c == null)
                    this.addChild(a);
                else
                    this.addChild(new Node(c));
		
	}
	
	
	
	
}

/*
class Mul<String> extends CNode{
	
	public Mul(String rootData,  Node<String> a, Node<String> b,int line) {
		super(rootData,line);
		
		this.addChild(a);
		this.addChild(b);
	}
	
	public void dump(){
		System.out.print("MUL\t");
	}
	
	
}


class Min<String> extends CNode{
	
	public Min(String rootData,  Node<String> a, Node<String> b,int line) {
		super(rootData,line);
		
		this.addChild(a);
		this.addChild(b);
	}
	
	public void dump(){
		System.out.print("MINUS\t");
	}
	
	
}

class Div<String> extends CNode{
	
	public Div(String rootData,  Node<String> a, Node<String> b,int line) {
		super(rootData,line);
		
		this.addChild(a);
		this.addChild(b);
	}
	
	public void dump(){
		System.out.print("DIVIDE\t");
	}
	
	
}

*/

class Cond<String> extends CNode{
	
	public Cond(String rootData,  Node<String> a, Node<String> b,int line) {
		super(rootData,line);
		
		this.addChild(a);
		this.addChild(b);
	}

	
}

class DecFunction<String> extends CNode{
	
	public DecFunction(String toReturn, Node<String>name,  Node<String> paramList, Node<String> body,int line) {
		super("DEC_FUN",line);
		this.addChild(new Node(toReturn));
		this.addChild(name);
		if(paramList != null ){
                    //se ho parametri avrò un nodo ParamFunction che ha come figli i nodi parametri
                    if(paramList.getChilds().get(0).getData() != ""){//se il primo figlio ha come Data una stringa diversa dal vuoto allora ho i parametri
                        //aggiungo l'albero "paramList"
                        this.addChild(paramList);
                    }else{
                        this.addChild(new Node("NO PARAM"));
                    }
                }else{
                        this.addChild(new Node("NO PARAM"));
                    }
		this.addChild(body);
	}
	
	
	
	
}




class ParamFunction<String> extends CNode{
		
	
	public ParamFunction(Node<String>name, String type,int line) {
		super(type,line);
		this.addChild(name);
		
	}
	
	
	
	
}


class CallFunction<String> extends CNode{
	
	public CallFunction(Node<String>name,  Node<String> paramList,int line) {
		super("FUNCALL ",line);
		this.addChild(name);
		if(paramList != null)
                    this.addChild(paramList);
		
	}
	
	
	
	
}

class Return<String> extends CNode{
	
	public Return(Node<String> toreturn,int line) {
		super("RETURN ",line);
		if(toreturn != null)
                    this.addChild(toreturn);
		
	}
	
	
	
	
}

class Const<String> extends CNode{
	
	public Const(Node<String> var,int line) {
		super("CONST ",line);
		this.addChild(var);
		
	}
	
	
	
	
}

class Volatile<String> extends CNode{
	
	public Volatile(Node<String> var,int line) {
		super("VOLATILE ",line);
		this.addChild(var);
		
	}
	
	
	
	
}


class ifElse<String> extends CNode{
	
	public ifElse(Node<String> ifCond,Node<String> body,int line) {
		super("IF",line);
                this.addChild(ifCond);
                this.addChild(body);
	}
	
	/*
	public ifElse(Node<String> ifCond,Node<String> body, Node<String> elseCond,int line) {
		super("IF_ELSE",line);
                this.addChild(ifCond);
                this.addChild(body);
                this.addChild(elseCond);
	}*/
	
	public ifElse(Node<String> ifCond,Node<String> body,Node<String> elseIfStm,int line) {
		super("IF",line);
                this.addChild(ifCond);
                this.addChild(elseIfStm);
                this.addChild(body);
	}
	
		
}


class ElseIf<String> extends CNode{
	
	public ElseIf(Node<String> ifCond,Node<String> body,int line) {
		super("ELSE_IF",line);
                this.addChild(ifCond);
                this.addChild(body);
	}
	
	
	
	
		
}


class Else<String> extends CNode{
	
	public Else(Node<String> body,int line) {
		super("ELSE",line);
                this.addChild(body);
	}
	
	
	
	
		
}


class StatementList<String> extends CNode{
	
	public StatementList(int line) {
		super("Statement",line);
		
		
	}
	
	
	
	
}


class whileLoop<String> extends CNode{
	
	
	
	public whileLoop(Node<String> cond,Node<String> body,int line) {
		super("WHILE",line);
                this.addChild(cond);
                this.addChild(body);
	}
	

	
}



class forLoop<String> extends CNode{
	
	
	
	public forLoop(Node<String> init,Node<String> cond, Node<String> incr,Node<String> body,int line) {
		super("FOR",line);
		this.addChild(init);
                this.addChild(cond);
                this.addChild(incr);
                this.addChild(body);
	}	
	
	
}



class Pointer<String> extends CNode{
	
	public Pointer(String op,String data,int line) {
		super("POINTER",line);
		this.addChild(new Node(op));
		this.addChild(new Node(data));
	}
	
	
}





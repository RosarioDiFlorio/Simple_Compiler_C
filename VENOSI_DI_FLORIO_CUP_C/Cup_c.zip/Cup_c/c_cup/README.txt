per compilare i file eseguire:

    sh precompiler.sh
    sh compiler.sh

da ora in poi si può lanciare solo il compiler.sh quando si fanno modifiche al .jflex o al file .cup
a questo punto si può lanciare il Parses

    java Parser <file input>
    

FILE DI TEST:

    input.c
    complicated.c
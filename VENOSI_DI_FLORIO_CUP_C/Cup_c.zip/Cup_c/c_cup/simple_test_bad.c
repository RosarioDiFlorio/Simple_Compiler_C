/*
 * In questo file sono stati posti alcuni errori sintattici,
 * il file è a scopo di test da dare in input ad analizzatore sintattico
 * al fine di mostrare il suo livello di gestione dell'errore
 * 
 */

//mancata chiusura di un istruzione con carattere ";"
const int MAX = 4

int main ()
{
    //mancato carattere "]"
    char *names[ = {
                    "Zara Ali",
                    "Hina Ali",
                    "Nuha Ali",
                    "Sara Ali"
    };
    
    int i = 0;
    
    //mancato carattere ";"  nella dichiarazione del costrutto for
    for ( i = 0 i < MAX ; i++)
    {
       printf("Value of names[%d] = %s\n", i, names[i] );
    }
    
 return 0;
 
}
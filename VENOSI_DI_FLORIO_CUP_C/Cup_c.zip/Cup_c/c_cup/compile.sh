jflex c.jflex
java -jar java-cup-11a.jar -expect 1000 -dump_grammar -interface -parser Parser c.cup
javac -cp "java-cup-11a.jar:jgraphx.jar" *.java

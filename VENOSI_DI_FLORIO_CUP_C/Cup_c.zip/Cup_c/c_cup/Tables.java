import java.util.Hashtable;

public class Tables {
	
	public static Hashtable<Integer,String> symTable = new Hashtable<Integer,String>();
	public static Hashtable<Integer,String> stringTable = new Hashtable<Integer,String>();
	public static Hashtable<Integer,String> numTable = new Hashtable<Integer,String>();
	
	

}


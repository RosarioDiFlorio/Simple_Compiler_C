//test precedenze

int b = 10 - 2 * 4;

int foo(int a, char b){
   
   int a = 0, c  = 3,b = 2;
  
    if(a % 2 == 0)int c = 3;
   a = 2 * (2 + 3);
   b = 2 * 2 + 3;
   
    
}